<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Captcha</title>
    <!----- CSS ------>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
<?php

$rand = substr(md5(rand()), 0, 6);

?>

    <div class="wrapper">
    <h1 class="heading">Captcha Text</h1>
        <form action="" method="post" class="form form-horizontal" id="form" autocomplete="off" autocapitalize="off" enctype="multipart/form-data">
            <input type="text" name="captcha_text" placeholder="Enter the Captcha Text Here" value="" id="captcha-text" class="form-control" required />
            <div class="captcha" id="captcha-code">
                <p class="captcha-code-text"><?php echo $rand; ?></p>
            </div>
            <input type="text" name="captcha_code" id="captcha-code" style="display: none;" value="<?php echo $rand; ?>" readonly aria-readonly="true" required />
            <button type="submit" name="submit" id="submit" class="submit" value="Submit">Submit</button>
        </form>
        <?php
        
        if(isset($_POST['submit'])){

            $captcha_text = $_POST['captcha_text'];

            if($captcha_text==$_POST['captcha_code']){
                echo "<span style='color: #16ec16;'>You are In!</span>";
            }else{
                echo "<span style='color: #f33b3b;'>Invalid Captcha</span>";
            }
        }
        
        ?>
    </div>
</body>
</html>